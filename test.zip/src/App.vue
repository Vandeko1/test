<template>
  <SaveLead msg="Hello Vue 3 + Vite" />
</template>

<script setup>
import SaveLead from './components/SaveLead.vue'

// This starter template is using Vue 3 experimental <script setup> SFCs
// Check out https://github.com/vuejs/rfcs/blob/script-setup-2/active-rfcs/0000-script-setup.md
</script>

<style scoped>
</style>
