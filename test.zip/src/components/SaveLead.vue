<template>
    <div>
        <form @submit="handleSubmit($event)">
            <label>Enter your name</label>
            <input type="text" :value="userName" @change="handleInput($event)"
            placeholder="https://goo.gl/maps/id" />
            <label>Enter your mail</label>
            <input type="text" :value="userName" @change="handleInput($event)"
            placeholder="https://goo.gl/maps/id" />
            <button type="submit" :disabled="isSubmitDisabled">SUBMIT</button>
            <button class="default">Login</button>
            <button class="outline">
            
            <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 480 480" style="enable-background:new 0 0 480 480;" xml:space="preserve">
<g>
	<g>
		<path d="M378.528,214.688l-21.088-24c-5.824-6.624-15.904-7.264-22.56-1.472L272,244.32V16c0-8.832-7.168-16-16-16h-32
			c-8.832,0-16,7.168-16,16v228.32l-62.88-55.104c-6.624-5.792-16.704-5.152-22.56,1.472l-21.088,23.968
			c-5.856,6.656-5.184,16.8,1.472,22.624l126.528,110.752c6.048,5.28,15.04,5.28,21.088,0L377.056,237.28
			C383.712,231.456,384.384,221.312,378.528,214.688z"/>
	</g>
</g>
<g>
	<g>
		<path d="M416,416H64c-8.832,0-16,7.168-16,16v32c0,8.832,7.168,16,16,16h352c8.832,0,16-7.168,16-16v-32
			C432,423.168,424.832,416,416,416z"/>
	</g>
</g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g>
</svg> Download Report</button>
            <button class="flat">
            
            <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 480 480" style="enable-background:new 0 0 480 480;" xml:space="preserve">
<g>
	<g>
		<path d="M378.528,214.688l-21.088-24c-5.824-6.624-15.904-7.264-22.56-1.472L272,244.32V16c0-8.832-7.168-16-16-16h-32
			c-8.832,0-16,7.168-16,16v228.32l-62.88-55.104c-6.624-5.792-16.704-5.152-22.56,1.472l-21.088,23.968
			c-5.856,6.656-5.184,16.8,1.472,22.624l126.528,110.752c6.048,5.28,15.04,5.28,21.088,0L377.056,237.28
			C383.712,231.456,384.384,221.312,378.528,214.688z"/>
	</g>
</g>
<g>
	<g>
		<path d="M416,416H64c-8.832,0-16,7.168-16,16v32c0,8.832,7.168,16,16,16h352c8.832,0,16-7.168,16-16v-32
			C432,423.168,424.832,416,416,416z"/>
	</g>
</g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g>
</svg>
           Download Report</button>
            <div v-if="errorRequired || errorMaxLength">
                {{ errorRequired || errorMaxLength }}!!!
            </div>
        </form>
    </div>
</template>

<script>
    export default {
        name: 'SaveLead',
        data() {
            return {
                userName: '',
                errorMaxLength: '',
                errorRequired: ''
            }
        },
        computed: {
            isSubmitDisabled() {
                return Boolean(this.errorMaxLength || this.errorRequired)
            }
        },
        methods: {
            handleSubmit(e) {
                e.preventDefault()
                console.log(this.userName)
            },
            handleInput(e) {
                this.userName = e.target.value
                this.errorMaxLength = this.userName.length > 5 ? 'Максимум 5 символів' : ''
                this.errorRequired = !this.userName ? 'Введіть що небудь' : ''
                console.log(this.userName.length);
            }
        }
    }
</script>

<style scoped>
    html, body, input, label, button  {
        font-family: "Segoe UI";
        font-size: 18px;
        color: #6a757b;
    }
    form {
        display: -webkit-flex;
        display: -moz-flex;
        display: -ms-flex;
        display: -o-flex;
        display: flex;
        -webkit-flex-direction: column;
        -moz-flex-direction: column;
        -ms-flex-direction: column;
        -o-flex-direction: column;
        flex-direction: column;
        background: #e5e5e5;
        padding: 15px;
    }
    label {
        padding: 5px;
    }
    input::placeholder {
        color: #e1e7f0;
    }
    input {
        border: 2px solid #eeb0b0;
        border-radius: 5px;
        padding: 4px 14px;
        margin: 5px;
        height: 2rem;
    }
    svg {
        width: 18px;
        height: 18px;
        fill: #00d395;
    }
    button {
        background-color: #00d395;
        border-radius: 5px;
        margin: 0.5rem 1rem;
        height: 2rem
    }
    .default {
        background: #00d395;
        color: #fff;
        border: 2px solid #00d395;
        font-weight: bolder;
    }
    .outline {
        background: none;
        color: #00d395;
        border: 2px solid #00d395;
        font-weight: bolder;
    }
    .flat {
        background: none;
        color: #00d395;
        border: none;
        font-weight: bolder;
    }
</style>